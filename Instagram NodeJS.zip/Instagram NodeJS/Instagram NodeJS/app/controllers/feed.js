module.exports.feed = function(application, req, res){
	res.render('feed/padrao');
}

