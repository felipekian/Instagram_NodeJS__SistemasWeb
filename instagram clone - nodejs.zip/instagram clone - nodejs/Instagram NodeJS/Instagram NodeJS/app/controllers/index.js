module.exports.index = function(application, req, res){
	res.render('index/padrao');
}
